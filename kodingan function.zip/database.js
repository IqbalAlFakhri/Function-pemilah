const database = [
    {
        "nama": "kangkung",
        "harga": 3000
    },{
        "nama": "telur",
        "harga": 2500
    },{
        "nama": "cabai",
        "harga": 5000
    },{
        "nama": "tempe",
        "harga": 7000
    },{
        "nama": "tahu",
        "harga": 8000
    },
];

module.exports = database;