const fs = require('fs');
const csv = require('csv-parser');
// const prompt=require("prompt-sync")({sigint:true});
// const dataset = require('./database');

// var input = prompt("Masukkan Uang Anda: ");
// var uang = parseInt(input);

// for (let count = 0; count < dataset.length; count++) {
//     const variabel = dataset[count];
//     console.log("Nama : "+ variabel.nama);
//     console.log("harga : "+ variabel.harga);

//     var hasil_desimal = uang/variabel.harga;
//     var hasil_bulat = Math.floor(hasil_desimal);

//     console.log("jumlah dapat : "+ hasil_bulat);
//     console.log('-----');
// }

const results = [];

fs.createReadStream('data.csv')
  .pipe(csv())
  .on('data', (data) => results.push(data))
  .on('end', () => {
    // Menampilkan data
    for (let count = 0; count < result.length; count++) {
        const variabel = result[count];
        console.log("Nama : "+ variabel.Nama);
        console.log("harga : "+ variabel.Harga);
    }
  });